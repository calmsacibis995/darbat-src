/* Automatically generated, don't edit */
/* Generated on: hyperion */
/* At: Wed, 09 Mar 2005 00:48:23 +0000 */
/* Linux version 2.6.9 (root@hyperion) (gcc version 3.3.4 (Debian 1:3.3.4-13)) #3 SMP Wed Jan 5 16:57:31 EST 2005 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#define CONFIG_ARCH_ARM 1
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I486
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Processor Type */
#define CONFIG_CPU_ARM_SA1100 1
#undef  CONFIG_CPU_ARM_XSCALE
#undef  CONFIG_CPU_ARM_ARM926
#undef  CONFIG_CPU_ARM_ARM920T
#undef  CONFIG_CPU_ARM_OMAP1510


/* Platform */
#define CONFIG_PLAT_PC99 1


/* Platform */
#define CONFIG_PLAT_PLEB 1
#undef  CONFIG_PLAT_PLEB2
#undef  CONFIG_PLAT_IXDP425
#undef  CONFIG_PLAT_INNOVATOR
#undef  CONFIG_PLAT_CSB337


/* Miscellaneous */
#define CONFIG_BOOTMEM_PAGES 1024
#define CONFIG_ENABLE_FASS 1
#define CONFIG_EXCEPTION_FASTPATH 1
#undef  CONFIG_ENABLE_PLEB_LARGEMEM



/* Kernel */
#define CONFIG_IPC_FASTPATH 1
#define CONFIG_DEBUG 1


/* Debugger */
#define CONFIG_KDB 1
#undef  CONFIG_KDB_ON_STARTUP
#undef  CONFIG_KDB_BREAKIN
#undef  CONFIG_KDB_NO_ASSERTS
#define CONFIG_ASSERT_LEVEL 2

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#define CONFIG_KMEM_TRACE 1



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_IA32_HTT
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_SPARC64_SAB82532
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_ARM_BIG_ENDIAN
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#define CONFIG_HAVE_MEMORY_CONTROL 1
#undef  CONFIG_IA32_PSE
#undef  CONFIG_ARM_V5
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_IA32_TSC
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_ACPI
#undef  CONFIG_SPARC64_Z8530
#define CONFIG_ALPHA_FASTPATH 1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_IA32_SYSENTER
/* That's all, folks! */
#define AUTOCONF_INCLUDED
