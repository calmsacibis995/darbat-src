/* Automatically generated, don't edit */
/* Generated on: nofx */
/* At: Tue, 11 Jan 2005 04:40:36 +0000 */
/* Linux version 2.6.10 (root@nofx) (gcc version 3.3.5 (Debian 1:3.3.5-5)) #1 Fri Jan 7 12:14:28 EST 2005 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#define CONFIG_ARCH_ALPHA 1
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4


/* System Type */
#undef  CONFIG_CPU_ALPHA_A21064
#undef  CONFIG_CPU_ALPHA_A21164
#undef  CONFIG_CPU_ALPHA_A21164A
#define CONFIG_CPU_ALPHA_A21264 1


/* Platform */
#undef  CONFIG_PLAT_PC99


/* Platform */
#undef  CONFIG_PLAT_MIATA
#undef  CONFIG_PLAT_MULTIA
#define CONFIG_PLAT_TSUNAMI 1


/* Miscellaneous */
#define CONFIG_MAX_NUM_ASIDS 256
#undef  CONFIG_PREEMPT_ASIDS
#define CONFIG_BOOTMEM_PAGES 1024
#define CONFIG_ALPHA_ADDRESS_BITS 43
#define CONFIG_ALPHA_CONSOLE_RESERVE 0x810000
#undef  CONFIG_USER_LOAD_PHYS



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#undef  CONFIG_SPIN_WHEELS
#define CONFIG_NO_CLOCK_IN_INT 1
#undef  CONFIG_ALPHA_PAL_IPC_FASTPATH


/* Debugger */
#define CONFIG_KDB 1

/* Consoles */
#define CONFIG_KDB_CONS_OF1275 1
#define CONFIG_KDB_CONS_PSIM_COM 1

#define CONFIG_KDB_ON_STARTUP 1
#define CONFIG_KDB_BREAKIN 1
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_SPARC64_SAB82532
#undef  CONFIG_IS_32BIT
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_ARM_BIG_ENDIAN
#define CONFIG_SWIZZLE_IO_ADDR 1
#define CONFIG_IS_64BIT 1
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_IA32_PSE
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_IA32_TSC
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_ACPI
#undef  CONFIG_SPARC64_Z8530
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
