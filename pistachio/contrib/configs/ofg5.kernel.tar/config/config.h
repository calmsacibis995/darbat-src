/* Automatically generated, don't edit */
/* Generated on: hyperion */
/* At: Thu, 20 Jan 2005 08:50:39 +0000 */
/* Linux version 2.6.9 (root@hyperion) (gcc version 3.3.4 (Debian 1:3.3.4-13)) #3 SMP Wed Jan 5 16:57:31 EST 2005 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#define CONFIG_ARCH_POWERPC64 1
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I486
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Platform */
#define CONFIG_PLAT_PC99 1


/* Platform */
#define CONFIG_PLAT_OFG5 1
#undef  CONFIG_PLAT_OFPOWER3
#undef  CONFIG_PLAT_OFPOWER4


/* Processor Type */
#undef  CONFIG_CPU_POWERPC64_POWER3
#undef  CONFIG_CPU_POWERPC64_POWER3p
#undef  CONFIG_CPU_POWERPC64_POWER4
#undef  CONFIG_CPU_POWERPC64_POWER4p
#define CONFIG_CPU_POWERPC64_PPC970 1


/* Miscellaneous */
#define CONFIG_BOOTMEM_PAGES 1024



/* Kernel */
#define CONFIG_DEBUG 1
#undef  CONFIG_PPC64_TRASH_OF


/* Debugger */
#define CONFIG_KDB 1

/* Consoles */
#undef  CONFIG_KDB_CONS_RTAS


/* Kernel Debugger Console */
#undef  CONFIG_KDB_CONS_KBD
#define CONFIG_KDB_CONS_COM 1
#undef  CONFIG_KDB_CONS_SKI

#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#define CONFIG_KDB_BREAKIN 1
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#define CONFIG_VERBOSE_INIT 1
#define CONFIG_TRACEPOINTS 1
#define CONFIG_KMEM_TRACE 1



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_IA32_FXSR
#define CONFIG_BIGENDIAN 1
#undef  CONFIG_SPARC64_SAB82532
#undef  CONFIG_IS_32BIT
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_ARM_BIG_ENDIAN
#undef  CONFIG_SWIZZLE_IO_ADDR
#define CONFIG_IS_64BIT 1
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#define CONFIG_HAVE_MEMORY_CONTROL 1
#undef  CONFIG_IA32_PSE
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_IA32_TSC
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_ACPI
#undef  CONFIG_SPARC64_Z8530
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
