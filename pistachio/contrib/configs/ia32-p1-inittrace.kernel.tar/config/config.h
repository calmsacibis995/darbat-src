/* Automatically generated, don't edit */
/* Generated on: hyperion */
/* At: Fri, 15 Oct 2004 04:05:50 +0000 */
/* Linux version 2.6.8.1 (root@hyperion) (gcc version 3.3.4 (Debian 1:3.3.4-11)) #2 Thu Oct 14 12:12:45 EST 2004 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#define CONFIG_ARCH_IA32 1
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I486
#define CONFIG_CPU_IA32_I586 1
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Platform */
#define CONFIG_PLAT_PC99 1

#undef  CONFIG_SMP

/* Miscellaneous */
#undef  CONFIG_IOAPIC



/* Kernel */
#define CONFIG_IPC_FASTPATH 1
#define CONFIG_DEBUG 1
#undef  CONFIG_IA32_SMALL_SPACES
#undef  CONFIG_PERFMON
#undef  CONFIG_SPIN_WHEELS


/* Debugger */
#define CONFIG_KDB 1

/* Kernel Debugger Console */
#undef  CONFIG_KDB_CONS_KBD
#define CONFIG_KDB_CONS_COM 1
#undef  CONFIG_KDB_CONS_SKI

#define CONFIG_KDB_COMPORT 0x3f8
#define CONFIG_KDB_COMSPEED 115200
#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#define CONFIG_KDB_BREAKIN 1
#undef  CONFIG_KDB_NO_ASSERTS
#undef  CONFIG_DEBUG_SYMBOLS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#define CONFIG_KMEM_TRACE 1
#define CONFIG_TRACEBUFFER 1
#undef  CONFIG_IA32_KEEP_LAST_BRANCHES



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_SPARC64_SAB82532
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#define CONFIG_IA32_PSE 1
#undef  CONFIG_SPARC64_ULTRASPARC2I
#define CONFIG_IA32_TSC 1
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_ACPI
#undef  CONFIG_SPARC64_Z8530
#define CONFIG_ALPHA_FASTPATH 1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
